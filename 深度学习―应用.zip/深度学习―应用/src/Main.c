#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>
#include <unistd.h>
#include "dy.h"
#include "hs.h"
int main(int argc, char** argv){
    FILE* fpw;
    FILE* fpb;
    fpw=fopen("/storage/emulated/0/download/aaa/wji0.cunchu","rb");
    fpb=fopen("/storage/emulated/0/download/aaa/bji0.cunchu","rb");
    for(int ctcspe0 = 0;ctcspe0 < meiceng;ctcspe0++) {
        for(int ctcspe1 = 0;ctcspe1 < ybrl;ctcspe1++) {
            fread(&(wji0[ctcspe0][ctcspe1]),sizeof(double),1,fpw);
            fread(&(bji0[ctcspe0][ctcspe1]),sizeof(double),1,fpb);
        }
    }
    fclose(fpw);
    fclose(fpb);
    fpw=fopen("/storage/emulated/0/download/aaa/wji.cunchu","rb");
    fpb=fopen("/storage/emulated/0/download/aaa/bji.cunchu","rb");
    for(int ctcs1 = 0;ctcs1 < cengshu;ctcs1++) {
        for(int ctcs2 = 0;ctcs2 < meiceng;ctcs2++) {
            for(int ctcs3 = 0;ctcs3 < meiceng;ctcs3++) {
                fread(&(wji[ctcs1][ctcs2][ctcs3]),sizeof(double),1,fpw);
                fread(&(bji[ctcs1][ctcs2][ctcs3]),sizeof(double),1,fpb);
            }
        }
    }
    fclose(fpw);
    fclose(fpb);
    fpw=fopen("/storage/emulated/0/download/aaa/wjiend.cunchu","rb");
    fpb=fopen("/storage/emulated/0/download/aaa/bjiend.cunchu","rb");
    for(int ctcs4 = 0;ctcs4 < meiceng;ctcs4++) {
        fread(&(wjiend[ctcs4]),sizeof(double),1,fpw);
        fread(&(bjiend[ctcs4]),sizeof(double),1,fpb);
    }
    fclose(fpw);
    fclose(fpb);
    while(1)
    {
        for(int ctcs1 = 0;ctcs1 < ybrl;ctcs1++) {
            /*int shuru;
            printf("请输入:");
            scanf("%d",&shuru);*/
            //xlji[ctcs1]=(double)shuru;
            xlji[ctcs1]=(double)(rand()%11+1);
        }
        //清零开始
        for(int ctql0 = 0;ctql0 < meiceng;ctql0++) {
            zji0[ctql0]=0.000000;
        }
        for(int ctql0 = 0;ctql0 < cengshu;ctql0++) {
            for(int ctql1 = 0;ctql1 < meiceng;ctql1++) {
                zji[ctql0][ctql1]=0.000000;
            }
        }
        zend=0.000000;
        for(int ctql2 = 0;ctql2 < cengshu+1;ctql2++) {
            for(int ctql3 = 0;ctql3 < meiceng;ctql3++) {
                xji[ctql2][ctql3]=0.000000;
            }
        }
        jieguo=0.000000;
        //清零结束
        for(int ct2 = 0;ct2 < meiceng;ct2++) {
            for(int ct3 = 0;ct3 < ybrl;ct3++) {
                zji0[ct2]+=xlji[ct3]*wji0[ct2][ct3]+bji0[ct2][ct3];
            }
            xji[0][ct2]=relu(zji0[ct2]);
        }
        for(int ct4 = 0;ct4 < cengshu;ct4++) {
            for(int ct5 = 0;ct5 < meiceng;ct5++) {
                for(int ct6 = 0;ct6 < meiceng;ct6++) {
                    zji[ct4][ct5]+=xji[ct4][ct5]*wji[ct4][ct5][ct6]+bji[ct4][ct5][ct6];
                }
                xji[ct4+1][ct5]=relu(zji[ct4][ct5]);
            }
        }
        for(int ct7 = 0;ct7 < meiceng;ct7++) {
            zend+=xji[cengshu][meiceng-1]*wjiend[ct7]+bjiend[ct7];
        }
        jieguo=tanh(zend);
        
        printf("\ntanh结果为%lf",jieguo);
        jieguo=relu(zend);
        printf("\nrelu结果为%lf",jieguo);
        sleep(1); 
    }
}
