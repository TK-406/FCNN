#include <stdio.h>
#include <stdlib.h>
#define ybrl 10
#define cengshu 5
#define meiceng 5
double xlji[ybrl];

double wji0[meiceng][ybrl];
double wji[cengshu][meiceng][meiceng];
double wjiend[meiceng];

double bji0[meiceng][ybrl];
double bji[cengshu][meiceng][meiceng];
double bjiend[meiceng];

double zji0[meiceng];
double zji[cengshu][meiceng];
double zend;

double xji[cengshu+1][meiceng];
double jieguo;